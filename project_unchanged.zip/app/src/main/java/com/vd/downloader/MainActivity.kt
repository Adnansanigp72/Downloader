package com.vd.downloader

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : Activity() {
    lateinit var web: WebView
    private var customView: View? = null

    /** Share করে আসা লিংক; পেজ লোড হওয়ার আগে এলে এখানে জমা থাকে */
    @Volatile
    var sharedUrl: String? = null

    private fun extractShared(i: Intent?): String? {
        if (i == null || i.action != Intent.ACTION_SEND) return null
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return null
        return Regex("https?://\\S+").find(text)?.value
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.setBackgroundColor(0xFF151515.toInt())

        // ১ সেকেন্ডের Loading (splash) পেজ: কালো ব্যাকগ্রাউন্ডে লোগো
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        val splash = ImageView(this).apply {
            setBackgroundColor(Color.BLACK)
            setImageResource(R.drawable.splash_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            val pad = (resources.displayMetrics.widthPixels * 0.14f).toInt()
            setPadding(pad, pad, pad, pad)
        }
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({
            splash.animate().alpha(0f).setDuration(250).withEndAction { root.removeView(splash) }.start()
        }, 1000)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }

        // https:// অরিজিন দেওয়া হয়, যাতে YouTube এমবেড প্লেয়ার কাজ করে
        val thumbDir = java.io.File(filesDir, "thumbs").apply { mkdirs() }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/thumbs/", WebViewAssetLoader.InternalStoragePathHandler(this, thumbDir))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                customView = view
                (window.decorView as FrameLayout).addView(
                    view, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                )
            }

            override fun onHideCustomView() {
                customView?.let { (window.decorView as FrameLayout).removeView(it) }
                customView = null
            }
        }

        web.addJavascriptInterface(Bridge(this), "Android")
        sharedUrl = extractShared(intent)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val u = extractShared(intent) ?: return
        sharedUrl = null
        web.evaluateJavascript("window.__browserUrl(${JSONObject.quote(u)})", null)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.__sync && window.__sync()", null)
    }

    fun openBrowser(url: String) {
        startActivityForResult(Intent(this, BrowserActivity::class.java).putExtra("url", url), 7)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val url = data?.getStringExtra("url") ?: return
            web.evaluateJavascript("window.__browserUrl(${JSONObject.quote(url)})", null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (customView != null) {
            web.webChromeClient?.onHideCustomView()
            return
        }
        web.evaluateJavascript("window.__back ? window.__back() : false") { r ->
            if (r != "true") finish()
        }
    }
}
