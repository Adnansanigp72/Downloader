package com.vd.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * ডাউনলোড চলার সময় অ্যাপটাকে "foreground service" বানিয়ে রাখে,
 * তাই অ্যাপ থেকে বেরিয়ে গেলেও ডাউনলোড থামে না।
 */
class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            NOTIF_ID,
            buildProgress(this, "ডাউনলোড চলছে...", -1),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        return START_NOT_STICKY
    }

    companion object {
        private const val NOTIF_ID = 4242
        private const val CH_PROGRESS = "dl_progress"
        private const val CH_DONE = "dl_done"
        private var active = 0

        private fun channels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_PROGRESS, "Download progress", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_DONE, "Download complete", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }

        private fun buildProgress(ctx: Context, text: String, pct: Int): Notification {
            channels(ctx)
            val open = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = NotificationCompat.Builder(ctx, CH_PROGRESS)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Video Downloader")
                .setContentText(if (pct >= 0) "$text  $pct%" else text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
            if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
            return b.build()
        }

        @Synchronized
        fun begin(ctx: Context) {
            active++
            ctx.startForegroundService(Intent(ctx, DownloadService::class.java))
        }

        @Synchronized
        fun end(ctx: Context) {
            active--
            if (active <= 0) {
                active = 0
                ctx.stopService(Intent(ctx, DownloadService::class.java))
            }
        }

        fun progress(ctx: Context, title: String, pct: Int) {
            ctx.getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildProgress(ctx, title.take(60), pct))
        }

        fun done(ctx: Context, name: String, uri: String, mime: String) {
            channels(ctx)
            val view = Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(uri), mime)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val pi = PendingIntent.getActivity(
                ctx, (System.nanoTime() % 100000).toInt(), view,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Download complete")
                .setContentText(name)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            ctx.getSystemService(NotificationManager::class.java)
                .notify((System.nanoTime() % 100000).toInt() + 10, n)
        }

        fun failed(ctx: Context, title: String, msg: String) {
            channels(ctx)
            val n = NotificationCompat.Builder(ctx, CH_DONE)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Download failed")
                .setContentText(title.take(60))
                .setStyle(NotificationCompat.BigTextStyle().bigText(msg.take(200)))
                .setAutoCancel(true)
                .build()
            ctx.getSystemService(NotificationManager::class.java)
                .notify((System.nanoTime() % 100000).toInt() + 10, n)
        }
    }
}
