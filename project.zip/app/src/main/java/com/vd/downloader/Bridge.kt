package com.vd.downloader

import android.content.ContentValues
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.Size
import java.io.FileOutputStream
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.widget.Toast
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/** HTML (JavaScript) থেকে ডাকা হয়। প্রতিটা কাজ ব্যাকগ্রাউন্ডে চলে, শেষে window.__cb(id, ok, data) ডাকে। */
class Bridge(private val act: MainActivity) {
    private val ctx: Context = act.applicationContext
    private val pool = Executors.newFixedThreadPool(3)
    private val prefs = ctx.getSharedPreferences("vd", Context.MODE_PRIVATE)
    private val dlPool = Executors.newFixedThreadPool(3)
    private val cm: ConnectivityManager = ctx.getSystemService(ConnectivityManager::class.java)

    private class Job(
        val id: Int,
        val url: String,
        val quality: String,
        val key: String,
        val title: String,
        var counted: Boolean = false,
    )

    /** Wi-Fi-only অবস্থায় মোবাইল ডাটায় চাপা ডাউনলোডগুলো এখানে জমে থাকে */
    private val pending = java.util.concurrent.CopyOnWriteArrayList<Job>()

    init {
        // নেটওয়ার্ক বদলালে (যেমন Wi-Fi এলে) pending ডাউনলোড শুরু করে
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { drain() }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { drain() }
            })
        } catch (_: Throwable) {}
    }

    private fun js(code: String) {
        try {
            act.runOnUiThread {
                try { act.web.evaluateJavascript(code, null) } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    private fun async(id: Int, exec: java.util.concurrent.Executor = pool, block: () -> String) {
        exec.execute {
            try {
                val result = block()
                js("window.__cb($id,true,${JSONObject.quote(result)})")
            } catch (e: Throwable) {
                val msg = (e.message ?: e.toString()).take(300)
                js("window.__cb($id,false,${JSONObject.quote(msg)})")
            }
        }
    }

    private fun jsonLines(text: String): List<JSONObject> =
        text.lineSequence().map { it.trim() }.filter { it.startsWith("{") }
            .mapNotNull { runCatching { JSONObject(it) }.getOrNull() }.toList()

    @Synchronized
    private fun addHistory(entry: JSONObject) {
        val old = JSONArray(prefs.getString("history", "[]"))
        val arr = JSONArray().put(entry)
        for (i in 0 until minOf(old.length(), 49)) arr.put(old.get(i))
        prefs.edit().putString("history", arr.toString()).apply()
    }

    @JavascriptInterface
    fun config(id: Int) = async(id) {
        JSONObject()
            .put("video_dir", "Movies/VideoDownloader")
            .put("music_dir", "Music/VideoDownloader")
            .put("android", true)
            .toString()
    }

    @JavascriptInterface
    fun history(id: Int) = async(id) { prefs.getString("history", "[]") ?: "[]" }

    @JavascriptInterface
    fun setNotify(on: Boolean) {
        prefs.edit().putBoolean("notify", on).apply()
    }

    @JavascriptInterface
    fun setMobileData(on: Boolean) {
        prefs.edit().putBoolean("mobile", on).apply()
        drain()
    }

    /** এখন কি শুধু মোবাইল ডাটায় আছি (Wi-Fi ছাড়া)? */
    private fun onCellular(): Boolean {
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
            !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun blocked(): Boolean = !prefs.getBoolean("mobile", true) && onCellular()

    /** pending ডাউনলোড এখন চালানো যাবে কি? (ইন্টারনেট আছে, আর Wi-Fi-only হলে মোবাইল ডাটায় নেই) */
    private fun canRunPending(): Boolean {
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        return prefs.getBoolean("mobile", true) || !caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }

    @Synchronized
    private fun drain() {
        if (pending.isEmpty() || !canRunPending()) return
        val jobs = pending.toList()
        pending.clear()
        jobs.forEach { j ->
            js("window.__state(${JSONObject.quote(j.key)},'run')")
            start(j)
        }
    }

    @JavascriptInterface
    fun toast(msg: String) {
        act.runOnUiThread { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
    }

    @JavascriptInterface
    fun search(id: Int, query: String) = async(id) {
        Engine.await()
        val req = YoutubeDLRequest("ytsearch12:$query")
        req.addOption("--flat-playlist")
        req.addOption("--dump-json")
        req.addOption("--no-warnings")
        val out = YoutubeDL.getInstance().execute(req).out
        val arr = JSONArray()
        for (j in jsonLines(out)) {
            val vid = j.optString("id")
            if (vid.isEmpty()) continue
            arr.put(
                JSONObject()
                    .put("id", vid)
                    .put("title", j.optString("title"))
                    .put("channel", j.optString("channel", j.optString("uploader")))
                    .put("duration", j.optDouble("duration", 0.0))
                    .put("thumb", "https://i.ytimg.com/vi/$vid/hqdefault.jpg")
                    .put("url", "https://www.youtube.com/watch?v=$vid")
            )
        }
        arr.toString()
    }

    @JavascriptInterface
    fun info(id: Int, url: String) = async(id) {
        Engine.await()
        val req = YoutubeDLRequest(url)
        req.addOption("--dump-json")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        val out = YoutubeDL.getInstance().execute(req).out
        val j = jsonLines(out).firstOrNull() ?: JSONObject()
        JSONObject()
            .put("title", j.optString("title"))
            .put("channel", j.optString("channel", j.optString("uploader")))
            .put("duration", j.optDouble("duration", 0.0))
            .toString()
    }

    /**
     * ডাউনলোড ব্যাকগ্রাউন্ডে চলে (foreground service)।
     * Wi-Fi-only অন থাকলে আর মোবাইল ডাটায় থাকলে ডাউনলোড "pending" থাকে, Wi-Fi এলে নিজে থেকে শুরু হয়।
     */
    @JavascriptInterface
    fun download(id: Int, url: String, quality: String, key: String, title: String) {
        val j = Job(id, url, quality, key, title)
        if (blocked()) {
            // service চালু রাখি, যাতে অ্যাপ ব্যাকগ্রাউন্ডে গেলেও Wi-Fi এলে শুরু করতে পারে
            j.counted = true
            DownloadService.begin(ctx)
            pending.add(j)
            DownloadService.progress(ctx, "Wi-Fi-এর অপেক্ষায় (${pending.size}টি)", -1)
            js("window.__state(${JSONObject.quote(key)},'pending')")
            return
        }
        start(j)
    }

    private fun start(j: Job) = async(j.id, dlPool) { run(j) }

    private fun run(j: Job): String {
        if (!j.counted) DownloadService.begin(ctx)
        val tmp = File(ctx.cacheDir, "dl_${System.currentTimeMillis()}_${j.id}").apply { mkdirs() }
        val result: JSONObject = try {
            Engine.await()
            val req = YoutubeDLRequest(j.url)
            req.addOption("--no-playlist")
            req.addOption("--no-warnings")
            req.addOption("-o", "${tmp.absolutePath}/%(title).80s.%(ext)s")
            req.addOption("--write-thumbnail")
            req.addOption("--convert-thumbnails", "jpg")
            val isAudio = j.quality == "mp3"
            if (isAudio) {
                req.addOption("-f", "bestaudio/best")
                req.addOption("-x")
                req.addOption("--audio-format", "mp3")
            } else {
                val h = j.quality.toIntOrNull() ?: 720
                req.addOption(
                    "-f",
                    "bestvideo[height<=$h][ext=mp4]+bestaudio[ext=m4a]/best[height<=$h][ext=mp4]/" +
                        "bestvideo[height<=$h]+bestaudio/best[height<=$h]/best"
                )
                req.addOption("--merge-output-format", "mp4")
            }

            var last = -1
            YoutubeDL.getInstance().execute(req, "dl${j.id}") { progress, _, _ ->
                val p = progress.toInt().coerceIn(0, 100)
                if (p != last) {
                    last = p
                    js("window.__progress(${j.id},$p)")
                    DownloadService.progress(ctx, j.title, p)
                }
            }

            val all = tmp.listFiles()?.filter { it.isFile } ?: emptyList()
            val imgExt = setOf("jpg", "jpeg", "png", "webp")
            val skipExt = imgExt + setOf("part", "ytdl", "json", "vtt", "srt")
            val file = all.filter { it.extension.lowercase() !in skipExt }.maxByOrNull { it.length() }
                ?: throw IllegalStateException("ফাইল তৈরি হয়নি")
            val thumbSrc = all.firstOrNull { it.extension.lowercase() in imgExt }

            val res = saveToGallery(file, isAudio)
            res.put("thumb", saveThumb(j.key, thumbSrc, Uri.parse(res.getString("uri")), isAudio))
            res.put("audio", isAudio)
            addHistory(
                JSONObject(res.toString())
                    .put("key", j.key)
                    .put("audio", isAudio)
            )
            if (prefs.getBoolean("notify", true)) {
                DownloadService.done(ctx, res.getString("name"), res.getString("uri"), res.getString("mime"))
            }
            res
        } catch (e: Throwable) {
            val msg = (e.message ?: e.toString()).take(300)
            addHistory(JSONObject().put("key", j.key).put("err", msg))
            if (prefs.getBoolean("notify", true)) DownloadService.failed(ctx, j.title, msg)
            throw e
        } finally {
            tmp.deleteRecursively()
            DownloadService.end(ctx)
        }
        return result.toString()
    }

    /** ফাইলটা Movies/VideoDownloader বা Music/VideoDownloader-এ রাখে, তাই গ্যালারি/মিউজিক অ্যাপে দেখা যায়। */
    private fun saveToGallery(file: File, isAudio: Boolean): JSONObject {
        val ext = file.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (isAudio) "audio/mpeg" else "video/mp4"
        val relPath = if (isAudio) "Music/VideoDownloader" else "Movies/VideoDownloader"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (isAudio) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(collection, values) ?: throw IllegalStateException("সেভ করা যায়নি")
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)

        return JSONObject()
            .put("name", file.name)
            .put("uri", uri.toString())
            .put("mime", mime)
            .put("path", "$relPath/${file.name}")
            .put("size", file.length())
            .put("duration", durationSec(file))
    }

    private fun durationSec(f: File): Double = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        ms / 1000.0
    } catch (_: Throwable) {
        0.0
    }

    /** থাম্বনেইল অ্যাপের ভেতরের ফোল্ডারে (thumbs/) রাখে, Play ট্যাবে দেখানোর জন্য। */
    private fun saveThumb(key: String, src: File?, mediaUri: Uri, isAudio: Boolean): String {
        val dir = File(ctx.filesDir, "thumbs").apply { mkdirs() }
        val out = File(dir, "$key.jpg")
        try {
            if (src != null && src.length() > 0) {
                src.copyTo(out, overwrite = true)
                return "thumbs/$key.jpg"
            }
            if (!isAudio) {
                val bmp = ctx.contentResolver.loadThumbnail(mediaUri, Size(480, 270), null)
                FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                return "thumbs/$key.jpg"
            }
        } catch (_: Throwable) {
        }
        return ""
    }

    @JavascriptInterface
    @Synchronized
    fun forget(key: String) {
        val old = JSONArray(prefs.getString("history", "[]"))
        val arr = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (o.optString("key") != key) arr.put(o)
        }
        prefs.edit().putString("history", arr.toString()).apply()
        File(File(ctx.filesDir, "thumbs"), "$key.jpg").delete()
    }

    @JavascriptInterface
    @Synchronized
    fun forgetAll() {
        prefs.edit().putString("history", "[]").apply()
        File(ctx.filesDir, "thumbs").listFiles()?.forEach { it.delete() }
    }

    @JavascriptInterface
    fun deleteFile(id: Int, uri: String) = async(id) {
        ctx.contentResolver.delete(Uri.parse(uri), null, null)
        "true"
    }

    @JavascriptInterface
    fun openFile(uri: String, mime: String) {
        act.runOnUiThread {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(uri), mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                act.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(act, "ফাইল খোলার অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun shareFile(uri: String, mime: String) {
        act.runOnUiThread {
            val i = Intent(Intent.ACTION_SEND)
                .setType(mime)
                .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.startActivity(Intent.createChooser(i, "Share"))
        }
    }

    @JavascriptInterface
    fun openBrowser(url: String) {
        act.runOnUiThread { act.openBrowser(url) }
    }
}
